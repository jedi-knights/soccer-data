import click

@click.command()
def cli():
    """Interact with USYS data"""
    print("USYS command")