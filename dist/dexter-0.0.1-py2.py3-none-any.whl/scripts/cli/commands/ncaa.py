import click

@click.command()
def cli():
    """Interact with NCAA data"""
    print("NCAA command")