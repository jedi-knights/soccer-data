import click

@click.command()
def cli():
    """Interact with GA data"""
    print("GA command")