import click

@click.command()
def cli():
    """Interact with ECNL data"""
    print("ECNL command")