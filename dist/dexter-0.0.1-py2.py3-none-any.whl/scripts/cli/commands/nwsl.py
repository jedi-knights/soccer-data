import click

@click.command()
def cli():
    """Interact with NWSL data"""
    print("NWSL command")