import click

from library import ussoccer

@click.group()
def cli():
    """Interact with US Soccer data"""
    print("US Soccer command")

@cli.group()
def player():
    """Interact with US Soccer players"""
    pass

@player.command()
@click.option("--gender", "-g", type=click.Choice(["male", "female"]), required=True, help="Specify a gender.")
def list(gender: str):
    """List the players from the national team."""
    if gender == "male":
        players = ussoccer.get_players("Male")
        for player in players:
            click.echo(player)
    elif gender == "female":
        players = ussoccer.get_players("Female")
        for player in players:
            click.echo(player)
    else:
        click.echo("Unknown gender!")    