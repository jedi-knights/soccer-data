import click

@click.command()
def cli():
    """Interact with MLS data"""
    print("MLS command")