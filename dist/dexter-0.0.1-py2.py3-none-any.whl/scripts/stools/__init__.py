import json
import uuid

def get_guid():
    return str(uuid.uuid4())

def save_json(dst_path, data, sort_keys=True):
    root = { "data": data }
    with open(dst_path, "w", encoding="utf-8") as f:
        json.dump(root, f, ensure_ascii=False, indent=2, sort_keys=sort_keys)

def load_json(file_path):
    f = open(file_path)

    root = json.load(f)
    data = root["data"]

    f.close()

    return data

def genpath(directory: str, fname: str, suffix: str = None) -> str:
    path = directory
    
    if path[-1] != "/":
        path += "/"
    
    tokens = fname.split(".")

    path += tokens[0]

    if suffix is not None:
        path += suffix

    path += "."
    path += tokens[1]

    return path