import os

from azure.cosmos import CosmosClient

settings = {
    'host': os.environ.get('ACCOUNT_HOST', 'https://thesoccerhub.documents.azure.com:443/'),
    'master_key': os.environ.get('ACCOUNT_KEY', 'TAU2FlYHZlkOZ5tmrqtFzy1XbUqky26FbOUAd7GFkb1w89i6RWbCBRrH6SFzespvUfDpsWjE3p7IkhMsJ93USg=='),
    'database_id': os.environ.get('COSMOS_DATABASE', 'ToDoList'),
    'container_id': os.environ.get('COSMOS_CONTAINER', 'Items'),
}


URL = os.environ['COSMOS_ACCOUNT_URI']
KEY = os.environ['COSMOS_ACCOUNT_KEY']
DATABASE_NAME = os.environ['DATABASE_NAME']

client = CosmosClient(URL, credential=KEY)
database = client.get_database_client(DATABASE_NAME)

