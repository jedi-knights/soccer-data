from common.config import GITHUB_DATA


def get_clubs():
    return GITHUB_DATA["GA"]["Clubs"]


def get_conferences():
    return GITHUB_DATA["GA"]["Conferences"]


def get_conference_name_from_cell(cell):
    if cell is None:
        return None

    elements = cell.find_all("strong")

    for element in elements:
        text = element.text
        text = text.strip()

        if len(text) > 0:
            text = text.upper()
            text = text.replace("CONFERENCE", "")
            text = text.strip()

            return text

    return None
